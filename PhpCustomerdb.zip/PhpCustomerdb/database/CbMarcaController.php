<?php

/**
 * CbMarcaController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idMarca</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbMarcaController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idMarca
     */
    public function readAll(){
        $query = "SELECT * FROM Marca;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idMarca
     */
    public function read($idMarca){
        $query = "SELECT * FROM Marca WHERE idMarca = '".$idMarca."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Marca con los parámetros pasados.
     
     * @param type $idMarca
     * @param type $nombre
     * @param type $estatus
     */
    function create($idMarca, $nombre,$estatus){ 
        $sqlInsert = "INSERT INTO Marca(idMarca, nombre,estatus)"
                 . "    VALUES ('".$idMarca."', '".$nombre."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Marca en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idMarca.
     * @param type $idMarca
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idMarca, $nombre,$estatus){        
        $sqlUpdate = "UPDATE Marca "
                . "   SET nombre    = '".$nombre."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idMarca  = '".$idMarca."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Marca en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Marca que pasamos como parámetro.
     * @param type $idMarca
     */
    public function delete($idMarca){ 
        $sqlDelete = 
            "DELETE FROM Marca"
            . "     WHERE   idMarca = '".$idMarca."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Marca en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
