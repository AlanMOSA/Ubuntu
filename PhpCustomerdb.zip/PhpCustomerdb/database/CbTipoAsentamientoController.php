<?php

/**
 * CbTipoAsentamientoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idTipoAsentamiento</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbTipoAsentamientoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idTipoAsentamiento
     */
    public function readAll(){
        $query = "SELECT * FROM TipoAsentamiento;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idTipoAsentamiento
     */
    public function read($idTipoAsentamiento){
        $query = "SELECT * FROM TipoAsentamiento WHERE idTipoAsentamiento = '".$idTipoAsentamiento."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo TipoAsentamiento con los parámetros pasados.
     
     * @param type $idTipoAsentamiento
     * @param type $nombre
     * @param type $estatus
     */
    function create($idTipoAsentamiento, $nombre,$estatus){ 
        $sqlInsert = "INSERT INTO TipoAsentamiento(idTipoAsentamiento, nombre,estatus)"
                 . "    VALUES ('".$idTipoAsentamiento."', '".$nombre."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento TipoAsentamiento en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idTipoAsentamiento.
     * @param type $idTipoAsentamiento
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idTipoAsentamiento, $nombre,$estatus){        
        $sqlUpdate = "UPDATE TipoAsentamiento "
                . "   SET nombre    = '".$nombre."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idTipoAsentamiento  = '".$idTipoAsentamiento."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento TipoAsentamiento en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el TipoAsentamiento que pasamos como parámetro.
     * @param type $idTipoAsentamiento
     */
    public function delete($idTipoAsentamiento){ 
        $sqlDelete = 
            "DELETE FROM TipoAsentamiento"
            . "     WHERE   idTipoAsentamiento = '".$idTipoAsentamiento."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un TipoAsentamiento en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
