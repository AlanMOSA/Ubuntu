<?php

/**
 * CbProveedorController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idProveedor</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbProveedorController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idProveedor
     */
    public function readAll(){
        $query = "SELECT * FROM Proveedor;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idProveedor
     */
    public function read($idProveedor){
        $query = "SELECT * FROM Proveedor WHERE idProveedor = '".$idProveedor."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Proveedor con los parámetros pasados.
     
     * @param type $idProveedor
     * @param type $nombre
     * @param type $apellidoPaterno
     * @param type $apellidoMaterno
     * @param type $Curp
     * @param type $Rfc
     * @param type $Nss
     * @param type $estatus
     */
    function create($idProveedor, $nombre, $apellidoPaterno, $apellidoMaterno, $Curp, $Rfc,$Nss,$estatus){ 
        $sqlInsert = "INSERT INTO Proveedor(idProveedor, nombre, apellidoPaterno, apellidoMaterno, Curp, Rfc,Nss,estatus)"
                 . "    VALUES ('".$idProveedor."', '".$nombre."', '".$apellidoPaterno."', '".$apellidoMaterno."', '".$Curp."', '".$Rfc."','".$Nss."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Proveedor en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idProveedor.
     * @param type $idProveedor
     * @param type $nombre
     * @param type $apellidoPaterno
     * @param type $apellidoMaterno
     * @param type $Curp
     * @param type $Rfc
     * @param type $Nss
     * @param type $estatus
     */
    public function update($idProveedor, $nombre, $apellidoPaterno, $apellidoMaterno, $Curp, $Rfc, $Nss, $estatus){        
        $sqlUpdate = "UPDATE Proveedor "
                . "   SET nombre    = '".$nombre."', "
                . " apellidoPaterno = '".$apellidoPaterno."', "
                . " apellidoMaterno = '".$apellidoMaterno."', "
                . "            Curp = '".$Curp."', "
                . "             Rfc = '".$Rfc."',"
                . "             Nss = '".$Nss."',"
                . "         estatus = '".$estatus."'"
                . " WHERE  idProveedor  = '".$idProveedor."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Proveedor en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Proveedor que pasamos como parámetro.
     * @param type $idProveedor
     */
    public function delete($idProveedor){ 
        $sqlDelete = 
            "DELETE FROM Proveedor"
            . "     WHERE   idProveedor = '".$idProveedor."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Proveedor en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
