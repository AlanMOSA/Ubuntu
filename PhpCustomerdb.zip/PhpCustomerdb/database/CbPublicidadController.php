<?php

/**
 * CbPublicidadController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idPublicidad</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbPublicidadController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idPublicidad
     */
    public function readAll(){
        $query = "SELECT * FROM Publicidad;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idPublicidad
     */
    public function read($idPublicidad){
        $query = "SELECT * FROM Publicidad WHERE idPublicidad = '".$idPublicidad."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Publicidad con los parámetros pasados.
     
     * @param type $idPublicidad
     * @param type $Tipo
     * @param type $descripcion
     * @param type $estatus
     */
    function create($idPublicidad, $Tipo, $descripcion,$estatus){ 
        $sqlInsert = "INSERT INTO Publicidad(idPublicidad, Tipo, descripcion,estatus)"
                 . "    VALUES ('".$idPublicidad."', '".$Tipo."', '".$descripcion."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Publicidad en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idPublicidad.
     * @param type $idPublicidad
     * @param type $Tipo
     * @param type $descripcion
     * @param type $estatus
     */
    public function update($idPublicidad, $Tipo, $descripcion,$estatus){        
        $sqlUpdate = "UPDATE Publicidad "
                . "   SET Tipo    = '".$Tipo."', "
                . " descripcion = '".$descripcion."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idPublicidad  = '".$idPublicidad."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Publicidad en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Publicidad que pasamos como parámetro.
     * @param type $idPublicidad
     */
    public function delete($idPublicidad){ 
        $sqlDelete = 
            "DELETE FROM Publicidad"
            . "     WHERE   idPublicidad = '".$idPublicidad."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Publicidad en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
