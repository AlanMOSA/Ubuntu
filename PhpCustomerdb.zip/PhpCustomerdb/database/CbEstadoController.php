<?php

/**
 * CbEstadoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idEstado</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbEstadoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idEstado
     */
    public function readAll(){
        $query = "SELECT * FROM Estado;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idEstado
     */
    public function read($idEstado){
        $query = "SELECT * FROM Estado WHERE idEstado = '".$idEstado."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Estado con los parámetros pasados.
     
     * @param type $idEstado
     * @param type $nombre
     * @param type $estatus
     */
    function create($idEstado, $nombre,$estatus){ 
        $sqlInsert = "INSERT INTO Estado(idEstado, nombre,estatus)"
                 . "    VALUES ('".$idEstado."', '".$nombre."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Estado en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idEstado.
     * @param type $idEstado
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idEstado, $nombre,$estatus){        
        $sqlUpdate = "UPDATE Estado "
                . "   SET nombre    = '".$nombre."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idEstado  = '".$idEstado."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Estado en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Estado que pasamos como parámetro.
     * @param type $idEstado
     */
    public function delete($idEstado){ 
        $sqlDelete = 
            "DELETE FROM Estado"
            . "     WHERE   idEstado = '".$idEstado."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Estado en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
