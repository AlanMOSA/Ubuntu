<?php

/**
 * CbFormaPagoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idFormaPago</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbFormaPagoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idFormaPago
     */
    public function readAll(){
        $query = "SELECT * FROM FormaPago;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idFormaPago
     */
    public function read($idFormaPago){
        $query = "SELECT * FROM FormaPago WHERE idFormaPago = '".$idFormaPago."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo FormaPago con los parámetros pasados.
     
     * @param type $idFormaPago
     * @param type $nombre
     * @param type $estatus
     */
    function create($idFormaPago, $nombre,$estatus){ 
        $sqlInsert = "INSERT INTO FormaPago(idFormaPago, nombre,estatus)"
                 . "    VALUES ('".$idFormaPago."', '".$nombre."', '".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento FormaPago en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idFormaPago.
     * @param type $idFormaPago
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idFormaPago, $nombre,$estatus){        
        $sqlUpdate = "UPDATE FormaPago "
                . "   SET nombre    = '".$nombre."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idFormaPago  = '".$idFormaPago."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento FormaPago en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el FormaPago que pasamos como parámetro.
     * @param type $idFormaPago
     */
    public function delete($idFormaPago){ 
        $sqlDelete = 
            "DELETE FROM FormaPago"
            . "     WHERE   idFormaPago = '".$idFormaPago."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un FormaPago en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
