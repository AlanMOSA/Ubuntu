<?php

/**
 * CbProductoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idProducto</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbProductoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idProducto
     */
    public function readAll(){
        $query = "SELECT * FROM Producto;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idProducto
     */
    public function read($idProducto){
        $query = "SELECT * FROM Producto WHERE idProducto = '".$idProducto."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Producto con los parámetros pasados.
     
     * @param type $idProducto
     * @param type $descripcion
     * @param type $precio
     * @param type $estatus
     */
    function create($idProducto, $descripcion, $precio,$estatus){ 
        $sqlInsert = "INSERT INTO Producto(idProducto, descripcion, precio,estatus)"
                 . "    VALUES ('".$idProducto."', '".$descripcion."', '".$precio."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Producto en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idProducto.
     * @param type $idProducto
     * @param type $descripcion
     * @param type $precio
     * @param type $estatus
     */
    public function update($idProducto, $descripcion, $precio,$estatus){        
        $sqlUpdate = "UPDATE Producto "
                . "   SET descripcion    = '".$descripcion."', "
                . " precio = '".$precio."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idProducto  = '".$idProducto."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Producto en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Producto que pasamos como parámetro.
     * @param type $idProducto
     */
    public function delete($idProducto){ 
        $sqlDelete = 
            "DELETE FROM Producto"
            . "     WHERE   idProducto = '".$idProducto."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Producto en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}