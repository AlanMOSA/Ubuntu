<?php

/**
 * CbVentaController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idVenta</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbVentaController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idVenta
     */
    public function readAll(){
        $query = "SELECT * FROM Venta;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idVenta
     */
    public function read($idVenta){
        $query = "SELECT * FROM Venta WHERE idVenta = '".$idVenta."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Venta con los parámetros pasados.
     
     * @param type $idVenta
     * @param type $fecha
     * @param type $monto
     * @param type $descripcion
     * @param type $idFormaPago
     * @param type $idFactura
     * @param type $estatus
     */
    function create($idVenta, $fecha, $monto, $descripcion, $idFormaPago, $idFactura,$estatus){ 
        $sqlInsert = "INSERT INTO Venta(idVenta, fecha, monto, descripcion, idFormaPago, idFactura,estatus)"
                 . "    VALUES ('".$idVenta."', '".$fecha."', '".$monto."', '".$descripcion."', '".$idFormaPago."', '".$idFactura."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Venta en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idVenta.
     * @param type $idVenta
     * @param type $fecha
     * @param type $monto
     * @param type $descripcion
     * @param type $idFormaPago
     * @param type $idFactura
     * @param type $estatus
     */
    public function update($idVenta, $fecha, $monto, $descripcion, $idFormaPago, $idFactura,$estatus){        
        $sqlUpdate = "UPDATE Venta "
                . "   SET fecha    = '".$fecha."', "
                . " monto = '".$monto."', "
                . " descripcion = '".$descripcion."', "
                . " idFormaPago = '".$idFormaPago."', "
                . "            idFactura = '".$idFactura."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idVenta  = '".$idVenta."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Venta en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Venta que pasamos como parámetro.
     * @param type $idVenta
     */
    public function delete($idVenta){ 
        $sqlDelete = 
            "DELETE FROM Venta"
            . "     WHERE   idVenta = '".$idVenta."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Venta en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
