<?php

/**
 * CbTipoProveedorController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idTipoProveedor</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbTipoProveedorController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idTipoProveedor
     */
    public function readAll(){
        $query = "SELECT * FROM TipoProveedor;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idTipoProveedor
     */
    public function read($idTipoProveedor){
        $query = "SELECT * FROM TipoProveedor WHERE idTipoProveedor = '".$idTipoProveedor."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo TipoProveedor con los parámetros pasados.
     
     * @param type $idTipoProveedor
     * @param type $nombre
     * @param type $idProveedor
     * @param type $estatus
     */
    function create($idTipoProveedor, $nombre,$idProveedor,$estatus){ 
        $sqlInsert = "INSERT INTO TipoProveedor(idTipoProveedor, nombre,idProveedor,estatus)"
                 . "    VALUES ('".$idTipoProveedor."', '".$nombre."','".$idProveedor."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento TipoProveedor en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idTipoProveedor.
     * @param type $idTipoProveedor
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idTipoProveedor, $nombre,$idProveedor,$estatus){        
        $sqlUpdate = "UPDATE TipoProveedor "
                . "   SET nombre    = '".$nombre."', "
                . "       idProveedor    = '".$idProveedor."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idTipoProveedor  = '".$idTipoProveedor."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento TipoProveedor en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el TipoProveedor que pasamos como parámetro.
     * @param type $idTipoProveedor
     */
    public function delete($idTipoProveedor){ 
        $sqlDelete = 
            "DELETE FROM TipoProveedor"
            . "     WHERE   idTipoProveedor = '".$idTipoProveedor."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un TipoProveedor en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
