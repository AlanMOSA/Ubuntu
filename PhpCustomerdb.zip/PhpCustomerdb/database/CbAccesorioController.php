<?php

/**
 * CbEmpleadoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idEmpleado</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbAccesorioController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idEmpleado
     */
    public function readAll(){
        $query = "SELECT * FROM Accesorio;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idAccesorio
     */
    public function read($idAccesorio){
        $query = "SELECT * FROM Accesorio WHERE idAccesorio = '".$idAccesorio."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Accesorio con los parámetros pasados.
     
     * @param type $idAccesorio
     * @param type $precio
     * @param type $descripcion
     * @param type $estatus
     */
    function create($idAccesorio, $precio, $descripcion,$estatus){ 
        $sqlInsert = "INSERT INTO Accesorio(idAccesorio, precio, descripcion, estatus)"
                 . "    VALUES ('".$idAccesorio."', '".$precio."', '".$descripcion."', '".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Accesorio en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idEmpleado.
     
     * @param type $idAccesorio
     * @param type $precio
     * @param type $descripcion
     * @param type $estatus
     */
    public function update($idAccesorio, $precio, $descripcion, $estatus){        
        $sqlUpdate = "UPDATE Accesorio "
                . "       SET precio    = '".$precio."', "
                . "         descripcion = '".$descripcion."', "
                . "             estatus = '".$estatus."'"
                . " WHERE  idAccesorio  = '".$idAccesorio."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Accesorio en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Accesorio que pasamos como parámetro.
     * @param type $idAccesorio
     */
    public function delete($idAccesorio){ 
        $sqlDelete = 
            "DELETE FROM Accesorio"
            . "     WHERE   idAccesorio = '".$idAccesorio."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Accesorio en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
