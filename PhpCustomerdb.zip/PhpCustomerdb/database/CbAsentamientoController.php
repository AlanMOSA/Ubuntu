<?php

/**
 * CbAsentamientoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idAsentamiento</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbAsentamientoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idEmpleado
     */
    public function readAll(){
        $query = "SELECT * FROM Asentamiento;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idAsentamiento
     */
    public function read($idAsentamiento){
        $query = "SELECT * FROM Asentamiento WHERE idAsentamiento = '".$idAsentamiento."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Asentamiento con los parámetros pasados.
     
     * @param type $idAsentamiento
     * @param type $nombre
     * @param type $codigoPostal
     * @param type $idMunicipio
     * @param type $idTipoAsentamiento
     * @param type $estatus
     */
    function create($idAsentamiento, $nombre, $codigoPostal, $idMunicipio, $idTipoAsentamiento,$estatus){ 
        $sqlInsert = "INSERT INTO Asentamiento(idAsentamiento, nombre, codigoPostal, idMunicipio, idTipoAsentamiento,estatus)"
                 . "    VALUES ('".$idAsentamiento."', '".$nombre."', '".$codigoPostal."', '".$idMunicipio."', '".$idTipoAsentamiento."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Asentamiento en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del Asentamiento que pasamos en el parámetro $idAsentamiento.
     * @param type $idAsentamiento
     * @param type $nombre
     * @param type $codigoPostal
     * @param type $idMunicipio
     * @param type $idTipoAsentamiento
     * @param type $estatus
     */
    public function update($idAsentamiento, $nombre, $codigoPostal, $idMunicipio, $idTipoAsentamiento,$estatus){        
        $sqlUpdate = "UPDATE Asentamiento "
                . "   SET nombre    = '".$nombre."', "
                . " codigoPostal = '".$codigoPostal."', "
                . " idMunicipio = '".$idMunicipio."', "
                . " idTipoAsentamiento = '".$idTipoAsentamiento."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idAsentamiento  = '".$idAsentamiento."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Empleado en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Asentamiento que pasamos como parámetro.
     * @param type $idAsentamiento
     */
    public function delete($idAsentamiento){ 
        $sqlDelete = 
            "DELETE FROM Asentamiento"
            . "     WHERE   idAsentamiento = '".$idAsentamiento."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Asentamiento en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
