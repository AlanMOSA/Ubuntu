<?php

/**
 * CbAutoParteController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idAutoParte</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbAutoParteController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idAutoParte
     */
    public function readAll(){
        $query = "SELECT * FROM AutoParte;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idAutoParte
     */
    public function read($idAutoParte){
        $query = "SELECT * FROM AutoParte WHERE idAutoParte = '".$idAutoParte."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo AutoParte con los parámetros pasados.
     
     * @param type $idAutoParte
     * @param type $precio
     * @param type $descripcion
     * @param type $idMarca
     * @param type $idTipoAutoParte
     * @param type $estatus
     */
    function create($idAutoParte, $precio, $descripcion, $idMarca, $idTipoAutoParte,$estatus){ 
        $sqlInsert = "INSERT INTO AutoParte(idAutoParte, precio, descripcion, idMarca, idTipoAutoParte,estatus)"
                 . "    VALUES ('".$idAutoParte."', '".$precio."', '".$descripcion."', '".$idMarca."', '".$idTipoAutoParte."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento AutoParte en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idAutoParte.
     * @param type $idAutoParte
     * @param type $precio
     * @param type $descripcion
     * @param type $idMarca
     * @param type $idTipoAutoParte
     * @param type $estatus
     */
    public function update($idAutoParte, $precio, $descripcion, $idMarca, $idTipoAutoParte,$estatus){        
        $sqlUpdate = "UPDATE AutoParte "
                . "   SET precio    = '".$precio."', "
                . " descripcion = '".$descripcion."', "
                . " idMarca = '".$idMarca."', "
                . " idTipoAutoParte = '".$idTipoAutoParte."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idAutoParte  = '".$idAutoParte."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento AutoParte en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el AutoParte que pasamos como parámetro.
     * @param type $idAutoParte
     */
    public function delete($idAutoParte){ 
        $sqlDelete = 
            "DELETE FROM AutoParte"
            . "     WHERE   idAutoParte = '".$idAutoParte."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un AutoParte en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
