<?php

/**
 * CbZonaController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idZona</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbZonaController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idZona
     */
    public function readAll(){
        $query = "SELECT * FROM Zona;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idZona
     */
    public function read($idZona){
        $query = "SELECT * FROM Zona WHERE idZona = '".$idZona."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Zona con los parámetros pasados.
     
     * @param type $idZona
     * @param type $nombre
     * @param type $estatus
     */
    function create($idZona, $nombre,$estatus){ 
        $sqlInsert = "INSERT INTO Zona(idZona, nombre,estatus)"
                 . "    VALUES ('".$idZona."', '".$nombre."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Zona en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idZona.
     * @param type $idZona
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idZona, $nombre,$estatus){        
        $sqlUpdate = "UPDATE Zona "
                . "   SET nombre    = '".$nombre."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idZona  = '".$idZona."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Zona en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Zona que pasamos como parámetro.
     * @param type $idZona
     */
    public function delete($idZona){ 
        $sqlDelete = 
            "DELETE FROM Zona"
            . "     WHERE   idZona = '".$idZona."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Zona en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
