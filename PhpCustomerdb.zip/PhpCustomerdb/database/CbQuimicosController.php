<?php

/**
 * CbQuimicosController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idQuimicos</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbQuimicosController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idQuimicos
     */
    public function readAll(){
        $query = "SELECT * FROM Quimicos;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idQuimicos
     */
    public function read($idQuimicos){
        $query = "SELECT * FROM Quimicos WHERE idQuimicos = '".$idQuimicos."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Quimicos con los parámetros pasados.
     
     * @param type $idQuimicos
     * @param type $descripcion
     * @param type $precio
     * @param type $estatus
     */
    function create($idQuimicos, $descripcion, $precio,$estatus){ 
        $sqlInsert = "INSERT INTO Quimicos(idQuimicos, descripcion, precio,estatus)"
                 . "    VALUES ('".$idQuimicos."', '".$descripcion."', '".$precio."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Quimicos en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idQuimicos.
     * @param type $idQuimicos
     * @param type $descripcion
     * @param type $precio
     * @param type $estatus
     */
    public function update($idQuimicos, $descripcion, $precio,$estatus){        
        $sqlUpdate = "UPDATE Quimicos "
                . "   SET descripcion    = '".$descripcion."', "
                . "          precio = '".$precio."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idQuimicos  = '".$idQuimicos."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Quimicos en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Quimicos que pasamos como parámetro.
     * @param type $idQuimicos
     */
    public function delete($idQuimicos){ 
        $sqlDelete = 
            "DELETE FROM Quimicos"
            . "     WHERE   idQuimicos = '".$idQuimicos."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Quimicos en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
