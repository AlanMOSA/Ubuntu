<?php

/**
 * CbMunicipioController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idMunicipio</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbMunicipioController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idMunicipio
     */
    public function readAll(){
        $query = "SELECT * FROM Municipio;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idMunicipio
     */
    public function read($idMunicipio){
        $query = "SELECT * FROM Municipio WHERE idMunicipio = '".$idMunicipio."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Municipio con los parámetros pasados.
     
     * @param type $idMunicipio
     * @param type $nombre
     * @param type $idEstado
     * @param type $estatus
     */
    function create($idMunicipio, $nombre, $idEstado, $estatus){ 
        $sqlInsert = "INSERT INTO Municipio(idMunicipio, nombre, idEstado, estatus)"
                 . "    VALUES ('".$idMunicipio."', '".$nombre."', '".$idEstado."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Municipio en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idMunicipio.
     * @param type $idMunicipio
     * @param type $nombre
     * @param type $idEstado
     * @param type $estatus
     */
    public function update($idMunicipio, $nombre, $idEstado, $estatus){        
        $sqlUpdate = "UPDATE Municipio "
                . "   SET nombre    = '".$nombre."', "
                . "        idEstado = '".$idEstado."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idMunicipio  = '".$idMunicipio."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Municipio en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Municipio que pasamos como parámetro.
     * @param type $idMunicipio
     */
    public function delete($idMunicipio){ 
        $sqlDelete = 
            "DELETE FROM Municipio"
            . "     WHERE   idMunicipio = '".$idMunicipio."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Municipio en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
