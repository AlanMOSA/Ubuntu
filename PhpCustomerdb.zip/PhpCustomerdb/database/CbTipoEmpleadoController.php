<?php

/**
 * CbTipoEmpleadoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idTipoEmpleado</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbTipoEmpleadoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idTipoEmpleado
     */
    public function readAll(){
        $query = "SELECT * FROM TipoEmpleado;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idTipoEmpleado
     */
    public function read($idTipoEmpleado){
        $query = "SELECT * FROM TipoEmpleado WHERE idTipoEmpleado = '".$idTipoEmpleado."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo TipoEmpleado con los parámetros pasados.
     
     * @param type $idTipoEmpleado
     * @param type $nombre
     * @param type $idEmpleado
     * @param type $estatus
     */
    function create($idTipoEmpleado, $nombre,$idEmpleado,$estatus){ 
        $sqlInsert = "INSERT INTO TipoEmpleado(idTipoEmpleado, nombre,idEmpleado,estatus)"
                 . "    VALUES ('".$idTipoEmpleado."', '".$nombre."','".$idEmpleado."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento TipoEmpleado en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idTipoEmpleado.
     * @param type $idTipoEmpleado
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idTipoEmpleado, $nombre,$idEmpleado,$estatus){        
        $sqlUpdate = "UPDATE TipoEmpleado "
                . "   SET nombre    = '".$nombre."', "
                . "       idEmpleado    = '".$idEmpleado."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idTipoEmpleado  = '".$idTipoEmpleado."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento TipoEmpleado en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el TipoEmpleado que pasamos como parámetro.
     * @param type $idTipoEmpleado
     */
    public function delete($idTipoEmpleado){ 
        $sqlDelete = 
            "DELETE FROM TipoEmpleado"
            . "     WHERE   idTipoEmpleado = '".$idTipoEmpleado."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un TipoEmpleado en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
