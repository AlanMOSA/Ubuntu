<?php

/**
 * CbFacturaController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idFactura</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbFacturaController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idFactura
     */
    public function readAll(){
        $query = "SELECT * FROM Factura;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idFactura
     */
    public function read($idFactura){
        $query = "SELECT * FROM Factura WHERE idFactura = '".$idFactura."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Factura con los parámetros pasados.
     
     * @param type $idFactura
     * @param type $fecha
     * @param type $monto
     * @param type $detalles
     * @param type $estatus
     */
    function create($idFactura, $fecha, $monto, $detalles,$estatus){ 
        $sqlInsert = "INSERT INTO Factura(idFactura, fecha, monto, detalles, estatus)"
                 . "    VALUES ('".$idFactura."', '".$fecha."', '".$monto."', '".$detalles."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Factura en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idFactura.
     * @param type $idFactura
     * @param type $fecha
     * @param type $monto
     * @param type $detalles
     * @param type $estatus
     */
    public function update($idFactura, $fecha, $monto, $detalles,$estatus){        
        $sqlUpdate = "UPDATE Factura "
                . "   SET fecha    = '".$fecha."', "
                . " monto = '".$monto."', "
                . " detalles = '".$detalles."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idFactura  = '".$idFactura."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Factura en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Factura que pasamos como parámetro.
     * @param type $idFactura
     */
    public function delete($idFactura){ 
        $sqlDelete = 
            "DELETE FROM Factura"
            . "     WHERE   idFactura = '".$idFactura."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Factura en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
