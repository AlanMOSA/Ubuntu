<?php

/**
 * CbCompraController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idCompra</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbCompraController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idCompra
     */
    public function readAll(){
        $query = "SELECT * FROM Compra;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idCompra
     */
    public function read($idCompra){
        $query = "SELECT * FROM Compra WHERE idCompra = '".$idCompra."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Compra con los parámetros pasados.
     
     * @param type $idCompra
     * @param type $fecha
     * @param type $monto
     * @param type $detalles
     * @param type $idFormaPago
     * @param type $idFactura
     * @param type $estatus
     */
    function create($idCompra, $fecha, $monto, $detalles, $idFormaPago, $idFactura,$estatus){ 
        $sqlInsert = "INSERT INTO Compra(idCompra, fecha, monto, detalles, idFormaPago, idFactura,estatus)"
                 . "    VALUES ('".$idCompra."', '".$fecha."', '".$monto."', '".$detalles."', '".$idFormaPago."', '".$idFactura."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Compra en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idCompra.
     * @param type $idCompra
     * @param type $fecha
     * @param type $monto
     * @param type $detalles
     * @param type $idFormaPago
     * @param type $idFactura
     * @param type $estatus
     */
    public function update($idCompra, $fecha, $monto, $detalles, $idFormaPago, $idFactura,$estatus){        
        $sqlUpdate = "UPDATE Compra "
                . "   SET fecha    = '".$fecha."', "
                . " monto = '".$monto."', "
                . " detalles = '".$detalles."', "
                . " idFormaPago = '".$idFormaPago."', "
                . "   idFactura = '".$idFactura."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idCompra  = '".$idCompra."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Compra en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Compra que pasamos como parámetro.
     * @param type $idCompra
     */
    public function delete($idCompra){ 
        $sqlDelete = 
            "DELETE FROM Compra"
            . "     WHERE   idCompra = '".$idCompra."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Compra en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
