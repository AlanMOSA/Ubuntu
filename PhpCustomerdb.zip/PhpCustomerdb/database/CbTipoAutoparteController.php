<?php

/**
 * CbTipoAutoparteController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idTipoAutoparte</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbTipoAutoparteController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idTipoAutoparte
     */
    public function readAll(){
        $query = "SELECT * FROM TipoAutoparte;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idTipoAutoparte
     */
    public function read($idTipoAutoparte){
        $query = "SELECT * FROM TipoAutoparte WHERE idTipoAutoparte = '".$idTipoAutoparte."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo TipoAutoparte con los parámetros pasados.
     
     * @param type $idTipoAutoparte
     * @param type $nombre
     * @param type $estatus
     */
    function create($idTipoAutoparte, $nombre,$estatus){ 
        $sqlInsert = "INSERT INTO TipoAutoparte(idTipoAutoparte, nombre,estatus)"
                 . "    VALUES ('".$idTipoAutoparte."', '".$nombre."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento TipoAutoparte en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idTipoAutoparte.
     * @param type $idTipoAutoparte
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idTipoAutoparte, $nombre,$estatus){        
        $sqlUpdate = "UPDATE TipoAutoparte "
                . "   SET nombre    = '".$nombre."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idTipoAutoparte  = '".$idTipoAutoparte."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento TipoAutoparte en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el TipoAutoparte que pasamos como parámetro.
     * @param type $idTipoAutoparte
     */
    public function delete($idTipoAutoparte){ 
        $sqlDelete = 
            "DELETE FROM TipoAutoparte"
            . "     WHERE   idTipoAutoparte = '".$idTipoAutoparte."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un TipoAutoparte en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
