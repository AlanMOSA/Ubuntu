<?php

/**
 * CbMoviliarioController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idMoviliario</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbMoviliarioController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idMoviliario
     */
    public function readAll(){
        $query = "SELECT * FROM Moviliario;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idMoviliario
     */
    public function read($idMoviliario){
        $query = "SELECT * FROM Moviliario WHERE idMoviliario = '".$idMoviliario."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Moviliario con los parámetros pasados.
     
     * @param type $idMoviliario
     * @param type $nombre
     * @param type $estatus
     */
    function create($idMoviliario, $nombre,$estatus){ 
        $sqlInsert = "INSERT INTO Moviliario(idMoviliario, nombre,estatus)"
                 . "    VALUES ('".$idMoviliario."', '".$nombre."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Moviliario en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idMoviliario.
     * @param type $idMoviliario
     * @param type $nombre
     * @param type $estatus
     */
    public function update($idMoviliario, $nombre, $estatus){        
        $sqlUpdate = "UPDATE Moviliario "
                . "   SET nombre    = '".$nombre."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idMoviliario  = '".$idMoviliario."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Moviliario en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Moviliario que pasamos como parámetro.
     * @param type $idMoviliario
     */
    public function delete($idMoviliario){ 
        $sqlDelete = 
            "DELETE FROM Moviliario"
            . "     WHERE   idMoviliario = '".$idMoviliario."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Moviliario en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
