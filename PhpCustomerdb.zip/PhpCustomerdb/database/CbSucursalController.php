<?php

/**
 * CbSucursalController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idSucursal</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbSucursalController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idSucursal
     */
    public function readAll(){
        $query = "SELECT * FROM Sucursal;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idSucursal
     */
    public function read($idSucursal){
        $query = "SELECT * FROM Sucursal WHERE idSucursal = '".$idSucursal."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Sucursal con los parámetros pasados.
     
     * @param type $idSucursal
     * @param type $nombre
     * @param type $direccion
     * @param type $estatus
     */
    function create($idSucursal, $nombre, $direccion,$estatus){ 
        $sqlInsert = "INSERT INTO Sucursal(idSucursal, nombre, direccion,estatus)"
                 . "    VALUES ('".$idSucursal."', '".$nombre."', '".$direccion."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Sucursal en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idSucursal.
     * @param type $idSucursal
     * @param type $nombre
     * @param type $direccion
     * @param type $estatus
     */
    public function update($idSucursal, $nombre, $direccion,$estatus){        
        $sqlUpdate = "UPDATE Sucursal "
                . "   SET nombre    = '".$nombre."', "
                . " direccion = '".$direccion."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idSucursal  = '".$idSucursal."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Sucursal en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Sucursal que pasamos como parámetro.
     * @param type $idSucursal
     */
    public function delete($idSucursal){ 
        $sqlDelete = 
            "DELETE FROM Sucursal"
            . "     WHERE   idSucursal = '".$idSucursal."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Sucursal en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}