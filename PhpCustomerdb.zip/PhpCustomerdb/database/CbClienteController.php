<?php

/**
 * CbClienteController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idCliente</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbClienteController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idCliente
     */
    public function readAll(){
        $query = "SELECT * FROM Cliente;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idCliente
     */
    public function read($idCliente){
        $query = "SELECT * FROM Cliente WHERE idCliente = '".$idCliente."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Cliente con los parámetros pasados.
     
     * @param type $idCliente
     * @param type $nombre
     * @param type $apellidoPaterno
     * @param type $apellidoMaterno
     * @param type $Curp
     * @param type $Rfc
     * @param type $idTipoCliente 
     * @param type $estatus
     */
    function create($idCliente, $nombre, $apellidoPaterno, $apellidoMaterno, $Curp, $Rfc,$idTipoCliente,$estatus){ 
        $sqlInsert = "INSERT INTO Cliente(idCliente, nombre, apellidoPaterno, apellidoMaterno, Curp, Rfc,idTipoCliente,estatus)"
                 . "    VALUES ('".$idCliente."', '".$nombre."', '".$apellidoPaterno."', '".$apellidoMaterno."', '".$Curp."', '".$Rfc."','".$idTipoCliente."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Cliente en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idCliente.
     * @param type $idCliente
     * @param type $nombre
     * @param type $apellidoPaterno
     * @param type $apellidoMaterno
     * @param type $Curp
     * @param type $Rfc
     * @param type $idTipoCliente 
     * @param type $estatus
     */
    public function update($idCliente, $nombre, $apellidoPaterno, $apellidoMaterno, $Curp, $Rfc,$idTipoCliente,$estatus){        
        $sqlUpdate = "UPDATE Cliente "
                . "   SET nombre    = '".$nombre."', "
                . " apellidoPaterno = '".$apellidoPaterno."', "
                . " apellidoMaterno = '".$apellidoMaterno."', "
                . "            Curp = '".$Curp."', "
                . "             Rfc = '".$Rfc."',"
                . "   idTipoCliente = '".$idTipoCliente."',"
                . "         estatus = '".$estatus."'"
                . " WHERE  idCliente  = '".$idCliente."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Cliente en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Cliente que pasamos como parámetro.
     * @param type $idCliente
     */
    public function delete($idCliente){ 
        $sqlDelete = 
            "DELETE FROM Cliente"
            . "     WHERE   idCliente = '".$idCliente."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Cliente en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
