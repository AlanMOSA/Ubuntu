<?php

/**
 * CbDescuentoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idDescuento</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbDescuentoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idDescuento
     */
    public function readAll(){
        $query = "SELECT * FROM Descuento;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idDescuento
     */
    public function read($idDescuento){
        $query = "SELECT * FROM Descuento WHERE idDescuento = '".$idDescuento."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo Descuento con los parámetros pasados.
     
     * @param type $idDescuento
     * @param type $fechaLimite
     * @param type $monto
     * @param type $detalles
     * @param type $idVenta
     * @param type $estatus
     */
    function create($idDescuento, $fechaLimite, $monto, $detalles, $idVenta,$estatus){ 
        $sqlInsert = "INSERT INTO Descuento(idDescuento, fechaLimite, monto, detalles, idVenta,estatus)"
                 . "    VALUES ('".$idDescuento."', '".$fechaLimite."', '".$monto."', '".$detalles."', '".$idVenta."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento Descuento en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idDescuento.
     * @param type $idDescuento
     * @param type $fechaLimite
     * @param type $monto
     * @param type $detalles
     * @param type $idVenta
     * @param type $estatus
     */
    public function update($idDescuento, $fechaLimite, $monto, $detalles, $idVenta,$estatus){        
        $sqlUpdate = "UPDATE Descuento "
                . "   SET fechaLimite   = '".$fechaLimite."', "
                . " monto = '".$monto."', "
                . " detalles = '".$detalles."', "
                . " idVenta = '".$idVenta."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idDescuento  = '".$idDescuento."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento Descuento en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el Descuento que pasamos como parámetro.
     * @param type $idDescuento
     */
    public function delete($idDescuento){ 
        $sqlDelete = 
            "DELETE FROM Descuento"
            . "     WHERE   idDescuento = '".$idDescuento."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un Descuento en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
