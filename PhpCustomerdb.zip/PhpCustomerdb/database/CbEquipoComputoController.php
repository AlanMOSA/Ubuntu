<?php

/**
 * CbEquipoComputoController clase donde agrupamos todas las acciones
 * CRUD (Create Read Update Delete), y otras utilidades adicionales para la
 * tabla de la base de datos <b>idEquipoComputo</b>.
 * @author Xules Puedes seguirme en mi web http://www.codigoxules.org).
 * You can follow me on my website http://www.codigoxules.org/en
 */
class CbEquipoComputoController {   
    var $cdb = null;
    /**
     * Devolvemos todos los resultados de la consulta sobre idEquipoComputo
     */
    public function readAll(){
        $query = "SELECT * FROM EquipoComputo;";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;         
    }        
    /**
     * 
     * @param type $idEquipoComputo
     */
    public function read($idEquipoComputo){
        $query = "SELECT * FROM EquipoComputo WHERE idEquipoComputo = '".$idEquipoComputo."';";
        $statement = $this->cdb->prepare($query);
        $statement->execute();
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
         
    }  
    
    /**
     * Creamos un nuevo EquipoComputo con los parámetros pasados.
     
     * @param type $idEquipoComputo
     * @param type $nombre
     * @param type $precio
     * @param type $marca
     * @param type $estatus
     */
    function create($idEquipoComputo, $nombre, $precio, $marca,$estatus){ 
        $sqlInsert = "INSERT INTO EquipoComputo(idEquipoComputo, nombre, precio, marca,estatus)"
                 . "    VALUES ('".$idEquipoComputo."', '".$nombre."', '".$precio."', '".$marca."','".$estatus."')";
        try {             
            $this->cdb->exec($sqlInsert);      
        } catch (PDOException $pdoException) {            
            echo 'Error crear un nuevo elemento EquipoComputo en create(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Actualizamos los valores del idioma que pasamos en el parámetro $idEquipoComputo.
     * @param type $idEquipoComputo
     * @param type $nombre
     * @param type $precio
     * @param type $marca
     * @param type $estatus
     */
    public function update($idEquipoComputo, $nombre, $precio, $marca,$estatus){        
        $sqlUpdate = "UPDATE EquipoComputo "
                . "   SET nombre    = '".$nombre."', "
                . " precio = '".$precio."', "
                . " marca = '".$marca."', "
                . "         estatus = '".$estatus."'"
                . " WHERE  idEquipoComputo  = '".$idEquipoComputo."'";
        try {                         
            $this->cdb->exec($sqlUpdate);      
        } catch (PDOException $pdoException) {            
            echo 'Error actualizar un nuevo elemento EquipoComputo en update(...): '.$pdoException->getMessage();
            exit();
        }
    }
    /**
     * Eliminamos el EquipoComputo que pasamos como parámetro.
     * @param type $idEquipoComputo
     */
    public function delete($idEquipoComputo){ 
        $sqlDelete = 
            "DELETE FROM EquipoComputo"
            . "     WHERE   idEquipoComputo = '".$idEquipoComputo."'"; 
        try {             
            $this->cdb->exec(
                $sqlDelete);      
        } catch (Exception $exception) {            
            echo 'Error al eliminar un EquipoComputo en la función delete(...): '.$exception->getMessage();
            exit();
        }
    }     
       
}
