<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<div class="table-responsive">
        <!-- Añadimos un botón para el diálogo modal -->
        <button type="button" 
                class="btn btn-lg btn-primary"
                class="btn btn-lg btn-danger"
                data-toggle="modal"
                data-toggle="modal2"
                data-target="#myModal"
                onclick="newCbEmpleado()"
                >NUEVO</button>  
        <table class="table table-striped">
            <tbody>
                <form role="form" name="formListCbEmpleado" method="post" action="index.php">
                
                <button id="edit-Empleado" name="edit-Empleado" type="button" 
                        class="btn btn-primary"
                        data-toggle="modal" 
                        data-target="#myModal"
                        onclick="openCbEmpleado('edit' 
                    Editar</button>
                            
                         
                        
        
                        
                </form>        
            </tbody>      
        </table>   
    </div>





<!-- 
        Create - Read - Update    
        Creamos una ventana Modal que utilizaremos para crear un nuevo Empleado, actualizarlo o mostrarlo.
            -->
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Formulario para un Empleado</h4>
                </div>
                <form role="form" name="formCbEmpleado" method="post" action="index.php">
                    <div class="modal-body">
                        <div class="input-group">
                            <label for="idEmpleado">IdEmpleado</label>
                            <input type="text" class="form-control" id="idEmpleado" name="idEmpleado" placeholder="" >
                            <small class="text-muted"></small>
                        </div>                                    
                        <div class="input-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="" >
                            <small class="text-muted"></small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="save-Empleado" name="save-Empleado" type="submit" class="btn btn-primary">Guardar</button>
                        <button id="update-Empleado" name="update-Empleado" type="submit" class="btn btn-primary">Actualizar</button>
                        <button id="cancel"type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>                                    
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->      
                                
</body>
</html>