        
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="favicon.ico">
        <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
        <!-----------------------------|||||||||------------------------------->
        <title>REFACCIONARIA DB - Dashboard Template for Bootstrap</title>

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/dashboard.css" rel="stylesheet">

        <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
        <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
        <script src="assets/js/ie-emulation-modes-warning.js"></script>

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>

    <body>
        

        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                            data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">REFACCIONARIA DB</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">Dashboard</a></li>             
                        <li><a href="#">Ayuda</a></li>
                        <!--<li><a href="http://localhost/PhpCustomerdb/index.php">Iniciar Seccion</li>-->
                        <li><a href="http://localhost/PhpCustomerdb/index.php">Iniciar Seccion</a></li>
                        
                    </ul>
                    <form class="navbar-form navbar-right">
                        <input type="text" class="form-control" placeholder="Search...">
                    </form>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-3 col-md-2 sidebar">
                    <ul class="nav nav-sidebar">
                        <li class="active"><a href="http://localhost/PhpCustomerdb/index.php">Empleados <span class="sr-only">(current)</span></a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexAccesorio.php">Accesorio</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexAsentamiento.php">Asentamiento</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexAutoParte.php">AutoParte</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexCliente.php">Cliente</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexCompra.php">Compra</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexDescuento.php">Descuento</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexEquipoComputo.php">EquipoComputo</a></li> 
                        <li><a href="http://localhost/PhpCustomerdb/indexEstado.php">Estado</a></li> 
                        <li><a href="http://localhost/PhpCustomerdb/indexFactura.php">Factura</a></li> 
                        <li><a href="http://localhost/PhpCustomerdb/indexFormaPago.php">FormaPago</a></li>                      
                        <li><a href="http://localhost/PhpCustomerdb/indexMarca.php">Marca</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexMoviliario.php">Moviliario</a></li>                       
                        <li><a href="http://localhost/PhpCustomerdb/indexMunicipio.php">Municipio</a></li>                      
                        <li><a href="http://localhost/PhpCustomerdb/indexProducto.php">Producto</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexProveedor.php">Proveedor</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexPublicidad.php">Publicidad</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexQuimicos.php">Quimicos</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexSucursal.php">Sucursal</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoAsentamiento.php">TipoAsentamiento</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoAutoParte.php">TipoAutoParte</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoEmpleado.php">TipoEmpleado</li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoProveedor.php">TipoProveedor</li>
                        <li><a href="http://localhost/PhpCustomerdb/indexVenta.php">Venta</li>
                        <li><a href="http://localhost/PhpCustomerdb/indexZona.php">Zona</li>
                        
                        <li><a href="">######</a></li>          
                    </ul>

                    <!--<ul class="nav nav-sidebar">            
                        <li><a href="">####</a></li>
                        <li><a href="">#####</a></li>
                    </ul>
                    <ul class="nav nav-sidebar">            
                        <li><a href="#">####</a></li>
                        <li><a href="#">###3</a></li>  
                        <li><a href="">#####</a></li>
                    </ul>-->
                </div>
                <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                    <!--##################################LOGIN#############################################################-->
                    
                    <div class="modal fade" id="" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="Login">
                                <div class="Login">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="">Formulario para un login</h4>
                                </div>
                                <form role="form" name="formCbLogin" method="post" action="index.php">
                                <span class="login100-form-title p-b-53">
                                  Sign In With
                                </span>
                                <a href="#" class="btn-face m-b-20">
                                    <i class="fa fa-facebook-official"></i>
                                    Facebook
                                </a>
                                <a href="#" class="btn-google m-b-20">
                                    <img src="images/icons/icon-google.png" alt="GOOGLE">
                                    Google
                                </a>
                                    <div class="modal-body">
                                        <div class="input-group">
                                            <label for="usuario">Usuario</label>
                                            <input type="text" class="form-control" id="usuario" name="usuario" placeholder="" >
                                            <small class="text-muted"></small>
                                        </div>                                    
                                        <div class="input-group">
                                            <label for="contraseña">Contraseña</label>
                                            <input type="text" class="form-control" id="contraseña" name="contraseña" placeholder="" >
                                            <small class="text-muted"></small>
                                        </div>
                                    </div>
                                    <div class="">
                                        <button id="LoginInicio-iniciar" name="LoginInicio-iniciar" type="submit" class="btn btn-danger">Iniciar</button>
                                        <button id="LoginCancelar-cancelar" name="LoginCancelar-cancelar" type="submit" class="btn btn-danger">Cancelar</button>
                                    </div>
                                </form>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->  
                    <!--########################################################################################################-->
                    <!-- Código PHP CRUD para presentar los Empleados. -->
                    <h2 class="sub-header">Empleados</h2>                
 
                    <?php
                        include './database/DatabaseConnect.php';
                        include './database/CbEmpleadoController.php';
                        
                        $dConnect = new DatabaseConnect;
                        $cdb = $dConnect->dbConnectSimple();
                        
                        $cbEmpleadoController = new CbEmpleadoController();                                                           
                        $cbEmpleadoController->cdb = $cdb;    
                        //////////ojo
                        if (isset($_POST["save-Empleado"]) || isset($_POST["update-Empleado"]) ) {  
                            $idEmpleado = $_POST['idEmpleado'];
                            $nombre = $_POST['nombre'];
                            $apellidoPaterno  = $_POST['apellidoPaterno'];
                            $apellidoMaterno = $_POST['apellidoMaterno'];
                            $fechaNacimiento = $_POST['fechaNacimiento'];
                            $Curp = $_POST['Curp'];
                            $Rfc = $_POST['Rfc'];
                            $Nss = $_POST['Nss'];
                            $estatus = $_POST['estatus']; 
                            if (isset($_POST["save-Empleado"])){
                                $cbEmpleadoController->create($idEmpleado, $nombre, $apellidoPaterno, $apellidoMaterno, $fechaNacimiento, $Curp, $Rfc,$Nss,$estatus);
                            }else{
                                $cbEmpleadoController->update($idEmpleado, $nombre, $apellidoPaterno, $apellidoMaterno, $fechaNacimiento, $Curp, $Rfc,$Nss,$estatus);
                            }
                        }else if (isset($_POST["delete-Empleado-select"]) ) { 
                            $idEmpleadoselect = $_POST['idEmpleadodelete'];
                            $cbEmpleadoController->delete($idEmpleadoselect);
                        }
                        
                        
                    ?>    
    
                    <div class="table-responsive">
                        <!-- Añadimos un botón para el diálogo modal -->
                        <button type="button" 
                                class="btn btn-lg btn-primary"
                                class="btn btn-lg btn-danger"
                                data-toggle="modal"
                                data-toggle="modal2"
                                data-target="#myModal"
                                onclick="newCbEmpleado()"
                                >NUEVO</button>  
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>idEmpleado</th>
                                    <th>Nombres</th>
                                    <th>Apellido Paterno</th>
                                    <th>Apellido Materno</th>
                                    <th>Fecha Nacimiento</th>
                                    <th>CURP</th>
                                    <th>RFC</th>
                                    <th>NSS</th>
                                    <th>ESTATUS</th>
                                    <th>ACCIONES</th>
                                </tr>
                            </thead>
                            <tbody>
                                <form role="form" name="formListCbEmpleado" method="post" action="index.php">
                                <?php
                                try {
                                    $rows = $cbEmpleadoController->readAll();                                                                        
                                    foreach ($rows as $row) {
                                        ?>
                                        <tr>
                                            <td><?php print($row->idEmpleado); ?></td>
                                            <td><?php print($row->nombre); ?></td>
                                            <td><?php print($row->apellidoPaterno); ?></td>
                                            <td><?php print($row->apellidoMaterno); ?></td>
                                            <td><?php print($row->fechaNacimiento); ?></td>
                                            <td><?php print($row->Curp); ?></td>
                                            <td><?php print($row->Rfc); ?></td>
                                            <td><?php print($row->Nss); ?></td>
                                            <td><?php print($row->estatus); ?></td>
                                            <td>
                                                <button id="edit-Empleado" name="edit-Empleado" type="button" 
                                                        class="btn btn-primary"
                                                        data-toggle="modal" 
                                                        data-target="#myModal"
                                                        onclick="openCbEmpleado('edit', 
                                                                    '<?php print($row->idEmpleado); ?>', '<?php print($row->nombre); ?>',
                                                                    '<?php print($row->apellidoPaterno); ?>', '<?php print($row->apellidoMaterno); ?>',
                                                                    '<?php print($row->fechaNacimiento); ?>', '<?php print($row->Curp); ?>',
                                                                    '<?php print($row->Rfc); ?>', '<?php print($row->Nss); ?>',
                                                                    '<?php print($row->estatus); ?>')">
                                                    Editar</button>
                                                <button id="see-Empleado" name="see-Empleado"type="button" class="btn btn-success"
                                                        data-toggle="modal" 
                                                        data-target="#myModal"
                                                        onclick="openCbEmpleado('see', 
                                                                    '<?php print($row->idEmpleado); ?>', '<?php print($row->nombre); ?>',
                                                                    '<?php print($row->apellidoPaterno); ?>', '<?php print($row->apellidoMaterno); ?>',
                                                                    '<?php print($row->fechaNacimiento); ?>', '<?php print($row->Curp); ?>',
                                                                    '<?php print($row->Rfc); ?>', '<?php print($row->Nss); ?>',
                                                                    '<?php print($row->estatus); ?>')">
                                                    Ver</button>
                                                <button id="delete-Empleado-modal" name="delete-Empleado-modal" type="button" 
                                                        class="btn btn-danger"
                                                        data-toggle="modal"
                                                        data-target="#myModalDelete"
                                                        onclick="deleteCbEmpleado('<?php print($row->idEmpleado); ?>')">Eliminar</button>    
                                            </td>
                                            </tr>      
                                        
                                    <?php
                                    }
                                } catch (Exception $exception) {
                                    echo 'Error hacer la consulta: ' . $exception;
                                }
                                ?>     
                                </form>        
                            </tbody>      
                        </table>   
                    </div>
                    
                    <!-- 
                        Create - Read - Update    
                        Creamos una ventana Modal que utilizaremos para crear un nuevo Empleado, actualizarlo o mostrarlo.
                            -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Formulario para un Empleado</h4>
                                </div>
                                <form role="form" name="formCbEmpleado" method="post" action="index.php">
                                    <div class="modal-body">
                                        <div class="input-group">
                                            <label for="idEmpleado">IdEmpleado</label>
                                            <input type="text" class="form-control" id="idEmpleado" name="idEmpleado" placeholder="" >
                                            <small class="text-muted"></small>
                                        </div>                                    
                                        <div class="input-group">
                                            <label for="nombre">Nombre</label>
                                            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="" >
                                            <small class="text-muted"></small>
                                        </div>
                                        <div class="input-group"> 
                                            <label for="apellidoPaterno">Apellido Paterno</label>
                                            <input type="text" class="form-control" id="apellidoPaterno" name="apellidoPaterno" placeholder="" aria-describedby="sizing-addon2">
                                        </div>
                                        <div class="input-group"> 
                                            <label for="apellidoMaterno">Apellido Materno</label>
                                            <input type="text" class="form-control" id="apellidoMaterno" name="apellidoMaterno" placeholder="" aria-describedby="sizing-addon2">
                                            <small class="text-muted"></small>
                                        </div>                          
                                        <div class="input-group"> 
                                            <label for="fechaNacimiento">Fecha Nacimiento</label>
                                            <input type="text" class="form-control" id="fechaNacimiento" name="fechaNacimiento" placeholder="" aria-describedby="sizing-addon2">
                                        </div>
                                        <div class="input-group"> 
                                            <label for="Curp">CURP</label>
                                            <input type="text" class="form-control" id="Curp" name="Curp" placeholder="" aria-describedby="sizing-addon2">
                                        </div>
                                        <div class="input-group"> 
                                            <label for="Rfc">RFC</label>
                                            <input type="text" class="form-control" id="Rfc" name="Rfc" placeholder="" aria-describedby="sizing-addon2">
                                            <small class="text-muted"></small>
                                        </div>
                                        <div class="input-group"> 
                                            <label for="Nss">NSS</label>
                                            <input type="text" class="form
                                            -control" id="Nss" name="Nss" placeholder="" aria-describedby="sizing-addon2">
                                            <small class="text-muted"></small>
                                        </div>
                                        <div class="input-group"> 
                                            <label for="estatus">Estatus</label>
                                            <input type="text" class="form-control" id="estatus" name="estatus" placeholder="" aria-describedby="sizing-addon2">
                                            <small class="text-muted"></small>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button id="save-Empleado" name="save-Empleado" type="submit" class="btn btn-primary">Guardar</button>
                                        <button id="update-Empleado" name="update-Empleado" type="submit" class="btn btn-primary">Actualizar</button>
                                        <button id="cancel"type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>                                    
                                    </div>
                                </form>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->      
                    
                    <!-- Modal DELETE -->
                    <div class="modal fade" id="myModalDelete" tabindex="-1" role="dialog" aria-labelledby="myModalDeleteLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalDeleteLabel">Eliminación de Empleado</h4>
                                </div>
                                <form role="form" name="formDeleteCbEmpleado" method="post" action="index.php">
                                    <div class="modal-body">                                    
                                            <div class="input-group">
                                                <label for="idEmpleado">¿Se va a eliminar el registro del Empleado seleccionado?</label>
                                            </div>       
                                            <div class="input-group">
                                                <label for="idEmpleado">Empleado</label>
                                                <input type="text" readonly class="form-control" id="idEmpleadodelete" name="idEmpleadodelete" placeholder="es_ES (por ejemplo)" >                                        
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                            <button id="delete-Empleado-select" name="delete-Empleado-select" type="submit" class="btn btn-primary">Aceptar</button>                                        
                                            <button id="cancel"type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>                                    
                                    </div>
                                </form>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->    
                    
                    <!-- Fin código PHP CRUD -->
                    
                </div>    
            </div>
        </div>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
        <script src="assets/js/vendor/holder.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
        <script>
            /**
             * Abrimos la ventana modal para crear un nuevo elemento.
             * We open a modal window to create a new element.
             * @returns {undefined}
             */
            function newCbEmpleado(){                 
                openCbEmpleado('new', null, null, null, null, null, null, null,null,null);
            }
            /**
             * Abrimos la ventana modal teniendo en cuenta la acción (action) para 
             * utilizarla como creación (Create), lectura (Read) o actualización (Update).
             * @param {type} action las acciones que utilizamos son : new para Create, see para Read y edit para Update.
             *      Actions we use are :  new for Create, see for Read and edit for Update.
             * @param {type} idEmpleado
             * @param {type} nombre
             * @param {type} apellidoPaterno
             * @param {type} apellidoMaterno
             * @param {type} fechaNacimiento
             * @param {type} Curp
             * @param {type} Rfc
             * @param {type} Nss
             * @param {type} estatus
             * @returns {undefined}
             */
            function openCbEmpleado(action, idEmpleado,nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento, Curp, Rfc, Nss,estatus){    
                document.formCbEmpleado.idEmpleado.value = idEmpleado;
                document.formCbEmpleado.nombre.value = nombre;
                document.formCbEmpleado.apellidoPaterno.value = apellidoPaterno;
                document.formCbEmpleado.apellidoMaterno.value = apellidoMaterno;
                document.formCbEmpleado.fechaNacimiento.value = fechaNacimiento;
                document.formCbEmpleado.Curp.value = Curp;
                document.formCbEmpleado.Rfc.value = Rfc;
                document.formCbEmpleado.Nss.value = Nss;
                document.formCbEmpleado.estatus.value = estatus;

                
                document.formCbEmpleado.idEmpleado.disabled = (action === 'see')?true:false;                
                document.formCbEmpleado.nombre.disabled = (action === 'see')?true:false; 
                document.formCbEmpleado.apellidoPaterno.disabled = (action === 'see')?true:false; 
                document.formCbEmpleado.apellidoMaterno.disabled = (action === 'see')?true:false; 
                document.formCbEmpleado.fechaNacimiento.disabled = (action === 'see')?true:false; 
                document.formCbEmpleado.Curp.disabled = (action === 'see')?true:false; 
                document.formCbEmpleado.Rfc.disabled = (action === 'see')?true:false; 
                document.formCbEmpleado.Nss.disabled = (action === 'see')?true:false;
                document.formCbEmpleado.estatus.disabled = (action === 'see')?true:false;
                
                $('#myModal').on('shown.bs.modal', function () {
                    var modal = $(this);
                    if (action === 'new'){                            
                        $('#save-Empleado').show();
                        $('#update-Empleado').hide();                
                        modal.find('.modal-title').text('Creación de Empleado');                    
                    }else if (action === 'edit'){
                        $('#save-Empleado').hide();                    
                        $('#update-Empleado').show();                       
                        modal.find('.modal-title').text('Actualizar Empleado');
                    }else if (action === 'see'){
                        $('#save-Empleado').hide();   
                        $('#update-Empleado').hide();                       
                        modal.find('.modal-title').text('Ver Empleado');
                    }
                    $('#idEmpleado').focus()
                });
            }        
            /**
             * Para borrar el Empleado seleccionado abrimos una ventana modal para 
             * que el usuario confirme si quiere eliminar el registro.
             * @param {type} idEmpleado
             * @returns {undefined}
             */
            function deleteCbEmpleado(idEmpleado){     
                document.formDeleteCbEmpleado.idEmpleadodelete.value = idEmpleado;                
                
                $('#myModalDelete').on('shown.bs.modal', function () {
                    $('#myInput').focus()
                });
            } 
        </script>
    <!--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||-->
    </body>
</html>