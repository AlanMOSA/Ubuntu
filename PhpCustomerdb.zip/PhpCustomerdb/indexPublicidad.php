        
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="favicon.ico">

        <title>REFACCIONARIA DB - Dashboard Template for Bootstrap</title>

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/dashboard.css" rel="stylesheet">

        <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
        <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
        <script src="assets/js/ie-emulation-modes-warning.js"></script>

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>

    <body>
        

        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" 
                            data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">REFACCIONARIA DB</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">Dashboard</a></li>             
                        <li><a href="#">Ayuda</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/index.php">Iniciar Seccion</a></li>
                    </ul>
                    <form class="navbar-form navbar-right">
                        <input type="text" class="form-control" placeholder="Search...">
                    </form>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
        <div class="row">
                <div class="col-sm-3 col-md-2 sidebar">
                    <ul class="nav nav-sidebar">
                        <li class="active"><a href="http://localhost/PhpCustomerdb/index.php">Empleados <span class="sr-only">(current)</span></a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexAccesorio.php">Accesorio</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexAsentamiento.php">Asentamiento</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexAutoParte.php">AutoParte</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexCliente.php">Cliente</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexCompra.php">Compra</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexDescuento.php">Descuento</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexEquipoComputo.php">EquipoComputo</a></li> 
                        <li><a href="http://localhost/PhpCustomerdb/indexEstado.php">Estado</a></li> 
                        <li><a href="http://localhost/PhpCustomerdb/indexFactura.php">Factura</a></li> 
                        <li><a href="http://localhost/PhpCustomerdb/indexFormaPago.php">FormaPago</a></li>                      
                        <li><a href="http://localhost/PhpCustomerdb/indexMarca.php">Marca</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexMoviliario.php">Moviliario</a></li>                       
                        <li><a href="http://localhost/PhpCustomerdb/indexMunicipio.php">Municipio</a></li>                      
                        <li><a href="http://localhost/PhpCustomerdb/indexProducto.php">Producto</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexProveedor.php">Proveedor</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexPublicidad.php">Publicidad</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexQuimicos.php">Quimicos</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexSucursal.php">Sucursal</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoAsentamiento.php">TipoAsentamiento</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoAutoParte.php">TipoAutoParte</a></li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoEmpleado.php">TipoEmpleado</li>
                        <li><a href="http://localhost/PhpCustomerdb/indexTipoProveedor.php">TipoProveedor</li>
                        <li><a href="http://localhost/PhpCustomerdb/indexVenta.php">Venta</li>
                        <li><a href="http://localhost/PhpCustomerdb/indexZona.php">Zona</li>
                        
                        <li><a href="">######</a></li>          
                    </ul>

                    <!--<ul class="nav nav-sidebar">            
                        <li><a href="">####</a></li>
                        <li><a href="">#####</a></li>
                    </ul>
                    <ul class="nav nav-sidebar">            
                        <li><a href="#">####</a></li>
                        <li><a href="#">###3</a></li>  
                        <li><a href="">#####</a></li>
                    </ul>-->
                </div>
                <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                   <!-- <h1 class="page-header">Dashboard</h1-->
                    <!--########################################################################################################-->
                    <!-- Código PHP CRUD para presentar los Publicidads. -->
                    <h2 class="sub-header">Publicidads</h2>                
 
                    <?php
                        include './database/DatabaseConnect.php';
                        include './database/CbPublicidadController.php';
                        
                        $dConnect = new DatabaseConnect;
                        $cdb = $dConnect->dbConnectSimple();
                        
                        $cbPublicidadController = new CbPublicidadController();                                                           
                        $cbPublicidadController->cdb = $cdb;    
                        //////////ojo
                        if (isset($_POST["save-Publicidad"]) || isset($_POST["update-Publicidad"]) ) {  
                            $idPublicidad = $_POST['idPublicidad'];
                            $Tipo = $_POST['Tipo'];
                            $descripcion  = $_POST['descripcion'];
                            $estatus = $_POST['estatus']; 
                            if (isset($_POST["save-Publicidad"])){
                                $cbPublicidadController->create($idPublicidad, $Tipo, $descripcion,$estatus);
                            }else{
                                $cbPublicidadController->update($idPublicidad, $Tipo, $descripcion,$estatus);
                            }
                        }else if (isset($_POST["delete-Publicidad-select"]) ) { 
                            $idPublicidadselect = $_POST['idPublicidaddelete'];
                            $cbPublicidadController->delete($idPublicidadselect);
                        }
                        
                        
                    ?>    
            
                    <div class="table-responsive">
                        <!-- Añadimos un botón para el diálogo modal -->
                        <button type="button" 
                                class="btn btn-lg btn-primary" 
                                data-toggle="modal" 
                                data-target="#myModal"
                                onclick="newCbPublicidad()"
                                >NUEVO</button>  
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>idPublicidad</th>
                                    <th>Tipo</th>
                                    <th>Descripcion</th>
                                    <th>ESTATUS</th>
                                    <th>ACCIONES</th>
                                </tr>
                            </thead>
                            <tbody>
                                <form role="form" name="formListCbPublicidad" method="post" action="indexPublicidad.php">
                                <?php
                                try {
                                    $rows = $cbPublicidadController->readAll();                                                                        
                                    foreach ($rows as $row) {
                                        ?>
                                        <tr>
                                            <td><?php print($row->idPublicidad); ?></td>
                                            <td><?php print($row->Tipo); ?></td>
                                            <td><?php print($row->descripcion); ?></td>
                                            <td><?php print($row->estatus); ?></td>
                                            <td>
                                                <button id="edit-Publicidad" name="edit-Publicidad" type="button" 
                                                        class="btn btn-primary"
                                                        data-toggle="modal" 
                                                        data-target="#myModal"
                                                        onclick="openCbPublicidad('edit', 
                                                                    '<?php print($row->idPublicidad); ?>', '<?php print($row->Tipo); ?>',
                                                                    '<?php print($row->descripcion); ?>', '<?php print($row->estatus); ?>')">
                                                    Editar</button>
                                                <button id="see-Publicidad" name="see-Publicidad"type="button" class="btn btn-success"
                                                        data-toggle="modal" 
                                                        data-target="#myModal"
                                                        onclick="openCbPublicidad('see', 
                                                                    '<?php print($row->idPublicidad); ?>', '<?php print($row->Tipo); ?>',
                                                                    '<?php print($row->descripcion); ?>', '<?php print($row->estatus); ?>')">
                                                    Ver</button>
                                                <button id="delete-Publicidad-modal" name="delete-Publicidad-modal" type="button" 
                                                        class="btn btn-danger"
                                                        data-toggle="modal"
                                                        data-target="#myModalDelete"
                                                        onclick="deleteCbPublicidad('<?php print($row->idPublicidad); ?>')">Eliminar</button>    
                                            </td>
                                            </tr>      
                                        
                                    <?php
                                    }
                                } catch (Exception $exception) {
                                    echo 'Error hacer la consulta: ' . $exception;
                                }
                                ?>     
                                </form>        
                            </tbody>      
                        </table>   
                    </div>
                    
                    <!-- 
                        Create - Read - Update    
                        Creamos una ventana Modal que utilizaremos para crear un nuevo Publicidad, actualizarlo o mostrarlo.
                            -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Formulario para un Publicidad</h4>
                                </div>
                                <form role="form" name="formCbPublicidad" method="post" action="indexPublicidad.php">
                                    <div class="modal-body">
                                        <div class="input-group">
                                            <label for="idPublicidad">IdPublicidad</label>
                                            <input type="text" class="form-control" id="idPublicidad" name="idPublicidad" placeholder="" >
                                            <small class="text-muted"></small>
                                        </div>                                    
                                        <div class="input-group">
                                            <label for="Tipo">Tipo</label>
                                            <input type="text" class="form-control" id="Tipo" name="Tipo" placeholder="" >
                                            <small class="text-muted"></small>
                                        </div>
                                        <div class="input-group"> 
                                            <label for="descripcion">Descripcion</label>
                                            <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="" aria-describedby="sizing-addon2">
                                        </div>
                                        <div class="input-group"> 
                                            <label for="estatus">Estatus</label>
                                            <input type="text" class="form-control" id="estatus" name="estatus" placeholder="" aria-describedby="sizing-addon2">
                                            <small class="text-muted"></small>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button id="save-Publicidad" name="save-Publicidad" type="submit" class="btn btn-primary">Guardar</button>
                                        <button id="update-Publicidad" name="update-Publicidad" type="submit" class="btn btn-primary">Actualizar</button>
                                        <button id="cancel"type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>                                    
                                    </div>
                                </form>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->      
                    
                    <!-- Modal DELETE -->
                    <div class="modal fade" id="myModalDelete" tabindex="-1" role="dialog" aria-labelledby="myModalDeleteLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalDeleteLabel">Eliminación de Publicidad</h4>
                                </div>
                                <form role="form" name="formDeleteCbPublicidad" method="post" action="indexPublicidad.php">
                                    <div class="modal-body">                                    
                                            <div class="input-group">
                                                <label for="idPublicidad">¿Se va a eliminar el registro del Publicidad seleccionado?</label>
                                            </div>       
                                            <div class="input-group">
                                                <label for="idPublicidad">Idioma</label>
                                                <input type="text" readonly class="form-control" id="idPublicidaddelete" name="idPublicidaddelete" placeholder="es_ES (por ejemplo)" >                                        
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                            <button id="delete-Publicidad-select" name="delete-Publicidad-select" type="submit" class="btn btn-primary">Aceptar</button>                                        
                                            <button id="cancel"type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>                                    
                                    </div>
                                </form>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->    
                    
                    <!-- Fin código PHP CRUD -->
                    
                </div>    
            </div>
        </div>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
        <script src="assets/js/vendor/holder.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
        <script>
            /**
             * Abrimos la ventana modal para crear un nuevo elemento.
             * We open a modal window to create a new element.
             * @returns {undefined}
             */
            function newCbPublicidad(){                 
                openCbPublicidad('new', null, null, null, null);
            }
            /**
             * Abrimos la ventana modal teniendo en cuenta la acción (action) para 
             * utilizarla como creación (Create), lectura (Read) o actualización (Update).
             * @param {type} action las acciones que utilizamos son : new para Create, see para Read y edit para Update.
             *      Actions we use are :  new for Create, see for Read and edit for Update.
             * @param {type} idPublicidad
             * @param {type} Tipo
             * @param {type} descripcion
             * @param {type} estatus
             * @returns {undefined}
             */
            function openCbPublicidad(action, idPublicidad,Tipo, descripcion,estatus){    
                document.formCbPublicidad.idPublicidad.value = idPublicidad;
                document.formCbPublicidad.Tipo.value = Tipo;
                document.formCbPublicidad.descripcion.value = descripcion;
                document.formCbPublicidad.estatus.value = estatus;

                
                document.formCbPublicidad.idPublicidad.disabled = (action === 'see')?true:false;                
                document.formCbPublicidad.Tipo.disabled = (action === 'see')?true:false; 
                document.formCbPublicidad.descripcion.disabled = (action === 'see')?true:false;
                document.formCbPublicidad.estatus.disabled = (action === 'see')?true:false;
                
                $('#myModal').on('shown.bs.modal', function () {
                    var modal = $(this);
                    if (action === 'new'){                            
                        $('#save-Publicidad').show();
                        $('#update-Publicidad').hide();                
                        modal.find('.modal-title').text('Creación de Publicidad');                    
                    }else if (action === 'edit'){
                        $('#save-Publicidad').hide();                    
                        $('#update-Publicidad').show();                       
                        modal.find('.modal-title').text('Actualizar Publicidad');
                    }else if (action === 'see'){
                        $('#save-Publicidad').hide();   
                        $('#update-Publicidad').hide();                       
                        modal.find('.modal-title').text('Ver Publicidad');
                    }
                    $('#idPublicidad').focus()
                });
            }        
            /**
             * Para borrar el Publicidad seleccionado abrimos una ventana modal para 
             * que el usuario confirme si quiere eliminar el registro.
             * @param {type} idPublicidad
             * @returns {undefined}
             */
            function deleteCbPublicidad(idPublicidad){     
                document.formDeleteCbPublicidad.idPublicidaddelete.value = idPublicidad;                
                
                $('#myModalDelete').on('shown.bs.modal', function () {
                    $('#myInput').focus()
                });
            } 
        </script>
    <!--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||-->
    </body>
</html>